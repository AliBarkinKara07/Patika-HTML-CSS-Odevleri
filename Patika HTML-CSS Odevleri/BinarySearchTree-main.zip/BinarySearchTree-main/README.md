# BinarySearchTree
BinarySearchTree Patika Odev3
1. [7, 5, 1, 8, 3, 6, 0, 9, 4, 2] dizisinin Binary Search Tree aşamalarını yazınız.

Root 7'dir. Root'un sağında 8, solunda 5 bulunur.

    5'in solunda 1, sağında 6 bulunur. 1'in solunda 0, sağında 3 bulunur. 3'ün solunda 2, sağında 4 bulunur. 8'in sağında 9 bulunur.
    
                  7
              (root)
             /      \
            5         8
          /   \        \
        1       6        9
      /   \
    0      3 
         /   \
        2      4
