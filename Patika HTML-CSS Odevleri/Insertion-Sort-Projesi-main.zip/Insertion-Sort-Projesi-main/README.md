# Insertion-Sort-Projesi
Insertion Sort Projesi Patika Veri Yapıları Ödevi 1 


Insertion-Sort-Projesi [22,27,16,2,18,6] = Insertion Sort dizisine göre aşamaları:

1- Yukarı verilen dizinin sort türüne göre aşamalarını yazınız.

aşama =[22,27,16,2,18,6] aşama =[16,22,27,2,18,6] aşama =[2,16,22,27,18,6] aşama =[2,16,18,22,27,6] aşama =[2,6,16,18,22,27] 2- Big-O gösterimini yazınız. worst case => n! =n*(n+1)/2 = (n^2+n)/2 = O(n^2)

3-Time Complexity: Average case: Aradığımız sayının ortada olması,Worst case: Aradığımız sayının sonda olması, Best case: Aradığımız sayının dizinin en başında olması.

4- Bu dizine göre 18 sayısı average case kapsamına girer.

[7,3,5,8,2,9,4,15,6] dizisinin Insertion Sort'a göre ilk 4 adımını yazınız.

aşama =[3,7,5,8,2,9,4,15,6] 

aşama =[3,5,7,8,2,9,4,15,6] 

aşama =[2,3,5,7,8,9,4,15,6] 

aşama =[2,3,4,5,7,8,9,15,6]
