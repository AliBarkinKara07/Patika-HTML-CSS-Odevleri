# Kodluyoruz-Ilk-Repo
Bu repo Kodluyoruz Front-end Eğitiminde oluşturduğumuz ilk repo.İçerisinde bir adet Readme dosyası, bir adet index.html barındırıyor.

Installation
Öncelikle projeyi clonelayın. (Buraya sizin reponuzdan aldığınız link gelecek)

https://github.com/AliBarkinKara07/Kodluyoruz-Ilk-Repo
Usage
Projeyi cloneladıktan sonra Visual Studio Code programında açınız.

Linux için:

cd kodluyoruzilkrepo
code .
Contributing
Pull requestler kabul edilir. Büyük değişiklikler için,lütfen önce neyi değiştirmek istediğinizi tartışmak için bir konu açınız.

License
